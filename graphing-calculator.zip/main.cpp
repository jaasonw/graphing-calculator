#include "include/GraphingCalc.h"
#include <iostream>

int main() {
    GraphingCalc g;
    return 0;
}