#include <SFML/Graphics.hpp>
#include <SFML/Graphics/VertexArray.hpp>
#include <cmath>

sf::VertexArray create_line(double x1, double y1, double x2, double y2, sf::Color color);