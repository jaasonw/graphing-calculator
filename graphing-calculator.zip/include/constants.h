#pragma once
// config constants
const int SCREEN_WIDTH = 1280;
const int SCREEN_HEIGHT = 720;
// this can probably go even lower, we dont need a 60 fps graph zzz
const int FPS = 60;