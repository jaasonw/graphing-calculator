#include "Graph.h"
#include "engine/Engine.h"

class GraphingCalc {
private:
    Engine engine;

public:
    GraphingCalc();
};
